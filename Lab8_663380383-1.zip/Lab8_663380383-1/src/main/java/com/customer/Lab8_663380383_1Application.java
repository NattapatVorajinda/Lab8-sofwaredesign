package com.customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab8_663380383_1Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab8_663380383_1Application.class, args);
	}

}
